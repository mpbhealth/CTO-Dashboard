import{r as n,q as z,m as te,x as T,j as e,aq as se,ai as A,at as ie,a6 as D,bl as ae,bm as ne,bn as oe,bo as re,bp as le,bq as de,br as ce,bs as xe,aJ as me}from"./react-vendor-Bwx__XUe.js";import{E as ge}from"./office-05PtlIje.js";import"./vendor-B6n4M5ha.js";import"./csv-BWKFWSAi.js";import"./query-C3fsR7i0.js";function Ne(){const[E,d]=n.useState(!1),[I,h]=n.useState(!1),[c,M]=n.useState(null),[v,j]=n.useState({}),[x,F]=n.useState(""),[N,u]=n.useState(""),[R,he]=n.useState(!1),[U,ue]=n.useState(!1),[O,be]=n.useState(!1),[Q,_]=n.useState("14"),[w,b]=n.useState(""),[S,p]=n.useState(""),[f,m]=n.useState(""),[l,q]=n.useState([{id:"1",title:"Q4 2025 Board Meeting",date:"2025-12-15",status:"Draft",sections:["Financial Summary","Key Metrics","Strategic Initiatives","Risk Analysis"],lastModified:"2025-10-24"},{id:"2",title:"Q3 2025 Board Meeting",date:"2025-09-20",status:"Published",sections:["Financial Summary","Operations Update","Growth Metrics"],lastModified:"2025-09-15"},{id:"3",title:"Special Board Meeting - Strategic Review",date:"2025-08-10",status:"Published",sections:["Market Analysis","5-Year Plan","Investment Opportunities"],lastModified:"2025-08-05"}]),[y]=n.useState([{name:"Quarterly Board Meeting",sections:["Executive Summary","Financial Summary","Key Metrics","Strategic Initiatives","Risk Analysis","Q&A","Action Items","Next Steps"],icon:z},{name:"Special Meeting",sections:["Meeting Purpose","Background","Key Discussion Points","Action Items","Next Steps"],icon:te},{name:"Annual Review",sections:["Year in Review","Financial Performance","Key Achievements","Market Position","Strategic Goals","Risk Assessment","Budget Overview","Organizational Updates","Technology Roadmap","Compliance Update","Q&A","Looking Ahead"],icon:T}]),H=t=>{switch(t){case"Draft":return"bg-yellow-100 text-yellow-700";case"In Review":return"bg-indigo-100 text-indigo-500";case"Published":return"bg-green-100 text-green-700";default:return"bg-gray-100 text-gray-700"}},K=()=>{if(!w||!S){alert("Please fill in all required fields");return}const s=y.find(a=>a.name===f)?.sections||["Executive Summary","Financial Summary","Key Metrics","Action Items"],o={id:String(l.length+1),title:w,date:S,status:"Draft",sections:s,lastModified:new Date().toISOString().split("T")[0]};q([o,...l]),d(!1),b(""),p(""),m("")},G=t=>{m(t),d(!0)},W=t=>{M(t);const s={};t.sections.forEach(o=>{s[o]=v[o]||""}),j(s),F(t.sections[0]||""),u(s[t.sections[0]]||""),h(!0)},Y=t=>{j(s=>({...s,[x]:N})),F(t),u(v[t]||"")},J=()=>{j(t=>({...t,[x]:N})),h(!1),M(null)},C=n.useRef(null),r=(t,s)=>{document.execCommand(t,!1,s),C.current&&u(C.current.innerHTML)},$=t=>{r(t?"insertOrderedList":"insertUnorderedList")},P=t=>{r(`justify${t}`)},X=t=>{const s=`
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <title>${t.title}</title>
          <style>
            body {
              font-family: Arial, sans-serif;
              line-height: 1.6;
              max-width: 800px;
              margin: 0 auto;
              padding: 40px;
            }
            h1 {
              color: #ec4899;
              border-bottom: 3px solid #ec4899;
              padding-bottom: 10px;
            }
            h2 {
              color: #1f2937;
              margin-top: 30px;
              border-bottom: 1px solid #e5e7eb;
              padding-bottom: 8px;
            }
            .metadata {
              background: #f9fafb;
              padding: 15px;
              border-radius: 8px;
              margin: 20px 0;
            }
            .metadata-item {
              margin: 5px 0;
            }
            .section {
              margin: 25px 0;
              padding: 15px;
              border-left: 4px solid #ec4899;
              background: #fef2f2;
            }
            .section-title {
              font-weight: bold;
              color: #1f2937;
              margin-bottom: 10px;
            }
            .status {
              display: inline-block;
              padding: 5px 12px;
              border-radius: 20px;
              font-size: 14px;
              font-weight: bold;
            }
            .status-draft {
              background: #fef3c7;
              color: #92400e;
            }
            .status-review {
              background: #fce7f3;
              color: #9f1239;
            }
            .status-published {
              background: #d1fae5;
              color: #065f46;
            }
          </style>
        </head>
        <body>
          <h1>${t.title}</h1>

          <div class="metadata">
            <div class="metadata-item"><strong>Meeting Date:</strong> ${t.date}</div>
            <div class="metadata-item"><strong>Status:</strong> <span class="status status-${t.status.toLowerCase().replace(" ","-")}">${t.status}</span></div>
            <div class="metadata-item"><strong>Last Modified:</strong> ${t.lastModified}</div>
            <div class="metadata-item"><strong>Total Sections:</strong> ${t.sections.length}</div>
          </div>

          <h2>Board Packet Contents</h2>

          ${t.sections.map((g,k)=>`
            <div class="section">
              <div class="section-title">${k+1}. ${g}</div>
              <div style="margin-top: 10px;">
                ${v[g]||'<p style="color: #6b7280; font-style: italic;">[Content for '+g+" will be added here. This section should include relevant data, analysis, and recommendations for board review.]</p>"}
              </div>
            </div>
          `).join("")}

          <h2>Action Items</h2>
          <div class="section">
            <p>• Review all sections before the board meeting</p>
            <p>• Prepare questions for the Q&A session</p>
            <p>• Submit feedback by ${new Date(new Date(t.date).getTime()-6048e5).toISOString().split("T")[0]}</p>
          </div>

          <h2>Next Steps</h2>
          <div class="section">
            <p>1. Finalize all section content</p>
            <p>2. Circulate to board members for review</p>
            <p>3. Schedule pre-meeting briefings if needed</p>
            <p>4. Confirm attendance and logistics</p>
          </div>

          <hr style="margin-top: 40px; border: none; border-top: 1px solid #e5e7eb;">
          <p style="text-align: center; color: #6b7280; font-size: 12px;">
            Generated on ${new Date().toLocaleDateString()} | MPB Health Board Portal
          </p>
        </body>
      </html>
    `,o=new Blob([s],{type:"application/msword"}),a=URL.createObjectURL(o),i=document.createElement("a");i.href=a,i.download=`${t.title.replace(/[^a-z0-9]/gi,"_")}_Board_Packet.doc`,document.body.appendChild(i),i.click(),document.body.removeChild(i),URL.revokeObjectURL(a)},V=t=>{const s=new ge,o=s.internal.pageSize.getWidth(),a=20;let i=20;s.setFillColor(236,72,153),s.rect(0,0,o,15,"F"),s.setTextColor(255,255,255),s.setFontSize(18),s.setFont("helvetica","bold"),s.text(t.title,a,10),s.setTextColor(0,0,0),i=25,s.setFontSize(10),s.setFont("helvetica","normal"),s.setFillColor(249,250,251),s.rect(a-5,i,o-2*a+10,25,"F"),i+=7,s.text(`Meeting Date: ${t.date}`,a,i),i+=6,s.text(`Status: ${t.status}`,a,i),i+=6,s.text(`Last Modified: ${t.lastModified}`,a,i),i+=6,s.text(`Total Sections: ${t.sections.length}`,a,i),i+=15,s.setFontSize(14),s.setFont("helvetica","bold"),s.text("Board Packet Contents",a,i),i+=10,s.setFontSize(10),s.setFont("helvetica","normal"),t.sections.forEach((B,Z)=>{i>270&&(s.addPage(),i=20),s.setFont("helvetica","bold"),s.text(`${Z+1}. ${B}`,a,i),i+=6,s.setFont("helvetica","italic"),s.setTextColor(107,114,128);const ee=`[Content for ${B} will be added here]`,L=s.splitTextToSize(ee,o-2*a);s.text(L,a+5,i),i+=L.length*5+8,s.setTextColor(0,0,0)}),i>240&&(s.addPage(),i=20),i+=5,s.setFontSize(14),s.setFont("helvetica","bold"),s.text("Action Items",a,i),i+=8,s.setFontSize(10),s.setFont("helvetica","normal"),s.text("• Review all sections before the board meeting",a,i),i+=6,s.text("• Prepare questions for the Q&A session",a,i),i+=6;const g=new Date(new Date(t.date).getTime()-10080*60*1e3).toISOString().split("T")[0];s.text(`• Submit feedback by ${g}`,a,i),s.setFontSize(8),s.setTextColor(107,114,128);const k=`Generated on ${new Date().toLocaleDateString()} | MPB Health Board Portal`;s.text(k,o/2,285,{align:"center"}),s.save(`${t.title.replace(/[^a-z0-9]/gi,"_")}_Board_Packet.pdf`)};return e.jsxs("div",{className:"w-full space-y-6",children:[e.jsxs("div",{className:"flex items-center justify-between",children:[e.jsxs("div",{children:[e.jsx("h1",{className:"text-3xl font-bold text-gray-900",children:"Board Packet Builder"}),e.jsx("p",{className:"text-gray-600 mt-1",children:"Create comprehensive board meeting materials"})]}),e.jsxs("button",{onClick:()=>d(!0),className:"flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-indigo-400 to-indigo-500 text-white rounded-lg hover:opacity-90 transition-opacity font-medium shadow-md",children:[e.jsx(se,{size:18}),"New Packet"]})]}),e.jsxs("div",{className:"grid grid-cols-1 md:grid-cols-3 gap-4",children:[e.jsxs("div",{className:"bg-white rounded-xl shadow-sm border p-5",children:[e.jsx("div",{className:"flex items-center justify-between mb-2",children:e.jsx(T,{size:18,className:"text-indigo-500"})}),e.jsx("div",{className:"text-2xl font-bold text-gray-900",children:l.length}),e.jsx("div",{className:"text-sm text-gray-500 mt-1",children:"Total Packets"})]}),e.jsxs("div",{className:"bg-white rounded-xl shadow-sm border p-5",children:[e.jsx("div",{className:"flex items-center justify-between mb-2",children:e.jsx(z,{size:18,className:"text-yellow-600"})}),e.jsx("div",{className:"text-2xl font-bold text-gray-900",children:l.filter(t=>t.status==="Draft").length}),e.jsx("div",{className:"text-sm text-gray-500 mt-1",children:"In Progress"})]}),e.jsxs("div",{className:"bg-white rounded-xl shadow-sm border p-5",children:[e.jsx("div",{className:"flex items-center justify-between mb-2",children:e.jsx(A,{size:18,className:"text-green-600"})}),e.jsx("div",{className:"text-2xl font-bold text-gray-900",children:l.filter(t=>t.status==="Published").length}),e.jsx("div",{className:"text-sm text-gray-500 mt-1",children:"Published"})]})]}),e.jsxs("div",{children:[e.jsx("h2",{className:"text-lg font-semibold text-gray-900 mb-4",children:"Recent Board Packets"}),e.jsx("div",{className:"w-full space-y-4",children:l.map(t=>e.jsxs("div",{className:"bg-white rounded-xl shadow-sm border p-6 hover:shadow-md transition-shadow",children:[e.jsxs("div",{className:"flex items-start justify-between mb-4",children:[e.jsxs("div",{children:[e.jsx("h3",{className:"text-lg font-semibold text-gray-900",children:t.title}),e.jsxs("div",{className:"flex items-center gap-4 text-sm text-gray-500 mt-1",children:[e.jsxs("div",{className:"flex items-center gap-1",children:[e.jsx(z,{size:14}),t.date]}),e.jsxs("span",{children:["Last modified: ",t.lastModified]})]})]}),e.jsx("span",{className:`px-3 py-1 rounded-full text-sm font-medium ${H(t.status)}`,children:t.status})]}),e.jsx("div",{className:"flex flex-wrap gap-2 mb-4",children:t.sections.map(s=>e.jsx("span",{className:"px-2 py-1 bg-gray-100 rounded text-xs text-gray-700",children:s},s))}),e.jsxs("div",{className:"flex gap-2",children:[e.jsxs("button",{onClick:()=>W(t),className:"flex items-center gap-1 px-4 py-2 bg-gradient-to-r from-indigo-400 to-indigo-500 text-white rounded-lg hover:opacity-90 transition-opacity text-sm font-medium shadow-md",children:[e.jsx(ie,{size:16}),"Edit"]}),e.jsxs("button",{onClick:()=>X(t),className:"flex items-center gap-1 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors text-sm font-medium",children:[e.jsx(T,{size:16}),"Export Word"]}),e.jsxs("button",{onClick:()=>V(t),className:"flex items-center gap-1 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors text-sm font-medium",children:[e.jsx(A,{size:16}),"Export PDF"]})]})]},t.id))})]}),e.jsxs("div",{children:[e.jsx("h2",{className:"text-lg font-semibold text-gray-900 mb-4",children:"Quick Start Templates"}),e.jsx("div",{className:"grid grid-cols-1 md:grid-cols-3 gap-4",children:y.map(t=>{const s=t.icon;return e.jsxs("div",{className:"bg-white rounded-xl shadow-sm border p-6 hover:shadow-md transition-shadow cursor-pointer",children:[e.jsx(s,{size:32,className:"text-indigo-500 mb-3"}),e.jsx("h3",{className:"font-semibold text-gray-900 mb-2",children:t.name}),e.jsxs("p",{className:"text-sm text-gray-500",children:[t.sections.length," sections included"]}),e.jsx("button",{onClick:()=>G(t.name),className:"mt-4 w-full px-4 py-2 bg-gradient-to-r from-indigo-400 to-indigo-500 text-white rounded-lg hover:opacity-90 transition-opacity text-sm font-medium shadow-md",children:"Use Template"})]},t.name)})})]}),E&&e.jsx("div",{className:"fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4",children:e.jsxs("div",{className:"bg-white rounded-xl shadow-xl max-w-md w-full p-6",children:[e.jsxs("div",{className:"flex items-center justify-between mb-6",children:[e.jsx("h2",{className:"text-2xl font-bold text-gray-900",children:"Create New Board Packet"}),e.jsx("button",{onClick:()=>{d(!1),b(""),p(""),m("")},className:"text-gray-400 hover:text-gray-600 transition-colors",children:e.jsx(D,{size:24})})]}),e.jsxs("div",{className:"space-y-4",children:[e.jsxs("div",{children:[e.jsxs("label",{className:"block text-sm font-medium text-gray-700 mb-2",children:["Packet Title ",e.jsx("span",{className:"text-red-500",children:"*"})]}),e.jsx("input",{type:"text",value:w,onChange:t=>b(t.target.value),placeholder:"e.g., Q1 2026 Board Meeting",className:"w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none"})]}),e.jsxs("div",{children:[e.jsxs("label",{className:"block text-sm font-medium text-gray-700 mb-2",children:["Meeting Date ",e.jsx("span",{className:"text-red-500",children:"*"})]}),e.jsx("input",{type:"date",value:S,onChange:t=>p(t.target.value),className:"w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none"})]}),e.jsxs("div",{children:[e.jsx("label",{className:"block text-sm font-medium text-gray-700 mb-2",children:"Template"}),e.jsxs("select",{value:f,onChange:t=>m(t.target.value),className:"w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none",children:[e.jsx("option",{value:"",children:"Custom (No Template)"}),y.map(t=>e.jsxs("option",{value:t.name,children:[t.name," (",t.sections.length," sections)"]},t.name))]})]}),f&&e.jsxs("div",{className:"bg-gray-50 rounded-lg p-4",children:[e.jsx("p",{className:"text-sm font-medium text-gray-700 mb-2",children:"Included Sections:"}),e.jsx("div",{className:"flex flex-wrap gap-2",children:y.find(t=>t.name===f)?.sections.map(t=>e.jsx("span",{className:"px-2 py-1 bg-white rounded text-xs text-gray-700 border",children:t},t))})]})]}),e.jsxs("div",{className:"flex gap-3 mt-6",children:[e.jsx("button",{onClick:()=>{d(!1),b(""),p(""),m("")},className:"flex-1 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors font-medium",children:"Cancel"}),e.jsx("button",{onClick:K,className:"flex-1 px-4 py-2 bg-gradient-to-r from-indigo-400 to-indigo-500 text-white rounded-lg hover:opacity-90 transition-opacity font-medium shadow-md",children:"Create Packet"})]})]})}),I&&c&&e.jsx("div",{className:"fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4",children:e.jsxs("div",{className:"bg-white rounded-xl shadow-xl w-full max-w-6xl h-[90vh] flex flex-col",children:[e.jsxs("div",{className:"flex items-center justify-between p-4 border-b",children:[e.jsxs("div",{children:[e.jsx("h2",{className:"text-xl font-bold text-gray-900",children:c.title}),e.jsx("p",{className:"text-sm text-gray-500",children:"Editing Board Packet"})]}),e.jsx("button",{onClick:()=>h(!1),className:"text-gray-400 hover:text-gray-600 transition-colors",children:e.jsx(D,{size:24})})]}),e.jsxs("div",{className:"flex flex-1 overflow-hidden",children:[e.jsx("div",{className:"w-64 border-r bg-gray-50 overflow-y-auto",children:e.jsxs("div",{className:"p-4",children:[e.jsx("h3",{className:"text-sm font-semibold text-gray-700 mb-3",children:"Sections"}),e.jsx("div",{className:"space-y-1",children:c.sections.map(t=>e.jsx("button",{onClick:()=>Y(t),className:`w-full text-left px-3 py-2 rounded-lg text-sm transition-colors ${x===t?"bg-indigo-100 text-indigo-500 font-medium":"hover:bg-gray-100 text-gray-700"}`,children:t},t))})]})}),e.jsxs("div",{className:"flex-1 flex flex-col",children:[e.jsx("div",{className:"border-b bg-gray-50 p-2",children:e.jsxs("div",{className:"flex items-center gap-1 flex-wrap",children:[e.jsxs("select",{value:Q,onChange:t=>{_(t.target.value),r("fontSize",t.target.value)},className:"px-2 py-1 border border-gray-300 rounded text-sm",children:[e.jsx("option",{value:"1",children:"Small"}),e.jsx("option",{value:"3",children:"Normal"}),e.jsx("option",{value:"5",children:"Large"}),e.jsx("option",{value:"7",children:"Extra Large"})]}),e.jsx("div",{className:"h-6 w-px bg-gray-300 mx-1"}),e.jsx("button",{onClick:()=>r("bold"),className:`p-2 rounded hover:bg-gray-200 transition-colors ${R?"bg-gray-200":""}`,title:"Bold",children:e.jsx(ae,{size:18})}),e.jsx("button",{onClick:()=>r("italic"),className:`p-2 rounded hover:bg-gray-200 transition-colors ${U?"bg-gray-200":""}`,title:"Italic",children:e.jsx(ne,{size:18})}),e.jsx("button",{onClick:()=>r("underline"),className:`p-2 rounded hover:bg-gray-200 transition-colors ${O?"bg-gray-200":""}`,title:"Underline",children:e.jsx(oe,{size:18})}),e.jsx("div",{className:"h-6 w-px bg-gray-300 mx-1"}),e.jsx("button",{onClick:()=>P("Left"),className:"p-2 rounded hover:bg-gray-200 transition-colors",title:"Align Left",children:e.jsx(re,{size:18})}),e.jsx("button",{onClick:()=>P("Center"),className:"p-2 rounded hover:bg-gray-200 transition-colors",title:"Align Center",children:e.jsx(le,{size:18})}),e.jsx("button",{onClick:()=>P("Right"),className:"p-2 rounded hover:bg-gray-200 transition-colors",title:"Align Right",children:e.jsx(de,{size:18})}),e.jsx("div",{className:"h-6 w-px bg-gray-300 mx-1"}),e.jsx("button",{onClick:()=>$(!1),className:"p-2 rounded hover:bg-gray-200 transition-colors",title:"Bullet List",children:e.jsx(ce,{size:18})}),e.jsx("button",{onClick:()=>$(!0),className:"p-2 rounded hover:bg-gray-200 transition-colors",title:"Numbered List",children:e.jsx(xe,{size:18})}),e.jsx("div",{className:"h-6 w-px bg-gray-300 mx-1"}),e.jsx("input",{type:"color",onChange:t=>r("foreColor",t.target.value),className:"w-8 h-8 rounded cursor-pointer",title:"Text Color"}),e.jsx("input",{type:"color",onChange:t=>r("hiliteColor",t.target.value),className:"w-8 h-8 rounded cursor-pointer",title:"Highlight Color"})]})}),e.jsx("div",{className:"flex-1 overflow-y-auto p-6 bg-white",children:e.jsxs("div",{className:"max-w-4xl mx-auto",children:[e.jsx("h3",{className:"text-2xl font-bold text-gray-900 mb-4",children:x}),e.jsx("div",{ref:C,contentEditable:!0,onInput:t=>u(t.currentTarget.innerHTML),dangerouslySetInnerHTML:{__html:N},className:"min-h-[400px] p-4 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500",style:{lineHeight:"1.6",fontSize:"14px"}})]})}),e.jsx("div",{className:"border-t p-4 bg-gray-50",children:e.jsxs("div",{className:"flex items-center justify-between",children:[e.jsxs("div",{className:"text-sm text-gray-600",children:["Section ",c.sections.indexOf(x)+1," of ",c.sections.length]}),e.jsxs("div",{className:"flex gap-3",children:[e.jsx("button",{onClick:()=>h(!1),className:"px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors font-medium",children:"Cancel"}),e.jsxs("button",{onClick:J,className:"flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-indigo-400 to-indigo-500 text-white rounded-lg hover:opacity-90 transition-opacity font-medium shadow-md",children:[e.jsx(me,{size:18}),"Save Changes"]})]})]})})]})]})]})})]})}export{Ne as CEOBoardPacket};
//# sourceMappingURL=CEOBoardPacket-BSCx0Ejy.js.map
