import{r as j,an as y,e as v,C as d,ao as c,j as e,x as o,l as m,aj as N,ap as a,S as x}from"./react-vendor-Bwx__XUe.js";import{u as f,a as w,b as C}from"./index-CNvYNPLA.js";import{V as z}from"./VisibilityBadge-D6q7dncy.js";import{S}from"./ShareModal-BUEq1WYq.js";import"./vendor-B6n4M5ha.js";import"./csv-BWKFWSAi.js";import"./query-C3fsR7i0.js";import"./office-05PtlIje.js";import"./supabase-vendor-eBI8805-.js";import"./ui-libs-RUH28Cwu.js";function A(){const{data:t}=f(),{data:g}=w(t?.org_id||"","CTO","CTO Workspace"),{data:n=[]}=C({workspaceId:g?.id}),[i,l]=j.useState(null),p=[{label:"System Uptime",value:"99.9%",trend:"+0.1%",status:"success",icon:y},{label:"Open Issues",value:"12",trend:"-3",status:"warning",icon:v},{label:"Deployments (30d)",value:"47",trend:"+8",status:"success",icon:d},{label:"Shared Resources",value:n.filter(s=>s.visibility!=="private").length.toString(),trend:"+2",status:"neutral",icon:c}],r=n.slice(0,5),h=t?.role==="ceo"||t?.role==="admin";return e.jsxs("div",{className:"w-full h-full",children:[e.jsxs("div",{className:"space-y-4 sm:space-y-6 md:space-y-8",children:[e.jsx("div",{className:"px-1",children:h?e.jsxs(e.Fragment,{children:[e.jsx("h1",{className:"text-xl sm:text-2xl md:text-3xl font-bold bg-gradient-to-r from-indigo-600 to-blue-600 bg-clip-text text-transparent",children:"CEO Dashboard — CTO Technology Overview"}),e.jsx("p",{className:"text-gray-600 mt-1 text-sm md:text-base",children:"Viewing CTO operations and technology metrics"})]}):e.jsxs(e.Fragment,{children:[e.jsxs("h1",{className:"text-xl sm:text-2xl md:text-3xl font-bold text-gray-900",children:["Welcome back, ",t?.display_name||"Vinnie"]}),e.jsx("p",{className:"text-gray-600 mt-1 text-sm md:text-base",children:"Here's your technology overview"})]})}),e.jsx("div",{className:"grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 md:gap-6",children:p.map(s=>{const u=s.icon,b={success:"bg-green-100 text-green-700",warning:"bg-yellow-100 text-yellow-700",neutral:"bg-indigo-100 text-indigo-700"};return e.jsxs("div",{className:`
                  bg-white rounded-xl md:rounded-2xl shadow-sm 
                  border border-gray-200 
                  p-4 sm:p-5 md:p-6
                  hover:border-indigo-200 hover:shadow-md
                  transition-all duration-200
                  touch-manipulation
                `,children:[e.jsxs("div",{className:"flex items-center justify-between mb-2 sm:mb-3",children:[e.jsx("div",{className:"p-1.5 sm:p-2 bg-gray-100 rounded-lg",children:e.jsx(u,{size:16,className:"text-gray-600 sm:w-5 sm:h-5"})}),e.jsx("span",{className:`
                      text-xs font-medium px-2 py-0.5 sm:py-1 rounded-full
                      ${b[s.status]}
                    `,children:s.trend})]}),e.jsx("div",{className:"text-xl sm:text-2xl md:text-3xl font-bold text-gray-900 mb-0.5 sm:mb-1",children:s.value}),e.jsx("div",{className:"text-xs sm:text-sm text-gray-500 truncate",children:s.label})]},s.label)})}),e.jsxs("div",{className:"grid grid-cols-1 lg:grid-cols-3 gap-4 sm:gap-6",children:[e.jsxs("div",{className:"lg:col-span-2 bg-white rounded-xl md:rounded-2xl shadow-sm border border-gray-200 overflow-hidden",children:[e.jsx("div",{className:"p-4 sm:p-6 border-b border-gray-200",children:e.jsxs("h2",{className:"text-base sm:text-lg font-semibold text-gray-900 flex items-center gap-2",children:[e.jsx(o,{size:20,className:"text-indigo-500"}),"Recent Resources"]})}),e.jsx("div",{className:"divide-y divide-gray-200",children:r.length===0?e.jsxs("div",{className:"p-6 sm:p-8 text-center text-gray-500",children:[e.jsx(o,{size:40,className:"mx-auto mb-3 text-gray-300"}),e.jsx("p",{className:"text-sm",children:"No resources yet"}),e.jsx("p",{className:"text-xs mt-1 text-gray-400",children:"Upload files or create documents to get started"})]}):r.map(s=>e.jsx("div",{className:`
                      p-3 sm:p-4 
                      hover:bg-gray-50 active:bg-gray-100
                      transition-colors duration-200
                      touch-manipulation
                    `,children:e.jsxs("div",{className:"flex items-center justify-between gap-3",children:[e.jsxs("div",{className:"flex-1 min-w-0",children:[e.jsxs("div",{className:"flex items-center gap-2 flex-wrap",children:[e.jsx("h3",{className:"font-medium text-gray-900 text-sm truncate",children:s.title}),e.jsx(z,{visibility:s.visibility})]}),e.jsxs("div",{className:"flex items-center gap-2 sm:gap-3 mt-1",children:[e.jsx("span",{className:"text-xs text-gray-500 capitalize",children:s.type}),e.jsx("span",{className:"text-xs text-gray-400",children:new Date(s.created_at).toLocaleDateString()})]})]}),e.jsxs("button",{onClick:()=>l(s),className:`
                          flex items-center gap-1.5 sm:gap-2 
                          px-2.5 sm:px-3 py-2 
                          text-xs sm:text-sm text-indigo-600 
                          hover:bg-indigo-50 active:bg-indigo-100
                          rounded-lg transition-colors
                          min-h-[36px]
                          touch-manipulation
                          flex-shrink-0
                        `,children:[e.jsx(c,{size:14}),e.jsx("span",{className:"hidden xs:inline",children:"Share"})]})]})},s.id))})]}),e.jsxs("div",{className:"space-y-4 sm:space-y-6",children:[e.jsxs("div",{className:"bg-white rounded-xl md:rounded-2xl shadow-sm border border-gray-200 p-4 sm:p-6",children:[e.jsxs("h2",{className:"text-base sm:text-lg font-semibold text-gray-900 flex items-center gap-2 mb-4",children:[e.jsx(m,{size:20,className:"text-indigo-500"}),"Quick Actions"]}),e.jsxs("div",{className:"space-y-2",children:[e.jsxs("button",{className:`
                    flex items-center justify-between
                    w-full px-4 py-3 
                    bg-indigo-50 text-indigo-700 rounded-xl 
                    hover:bg-indigo-100 active:bg-indigo-200
                    active:scale-[0.98]
                    transition-all duration-200 
                    font-medium text-sm
                    min-h-[44px]
                    touch-manipulation
                  `,children:[e.jsxs("span",{className:"flex items-center gap-2",children:[e.jsx(N,{size:16}),"Upload File"]}),e.jsx(a,{size:16})]}),e.jsxs("button",{className:`
                    flex items-center justify-between
                    w-full px-4 py-3 
                    bg-gray-50 text-gray-700 rounded-xl 
                    hover:bg-gray-100 active:bg-gray-200
                    active:scale-[0.98]
                    transition-all duration-200 
                    font-medium text-sm
                    min-h-[44px]
                    touch-manipulation
                  `,children:[e.jsxs("span",{className:"flex items-center gap-2",children:[e.jsx(m,{size:16}),"View KPIs"]}),e.jsx(a,{size:16})]}),e.jsxs("button",{className:`
                    flex items-center justify-between
                    w-full px-4 py-3 
                    bg-gray-50 text-gray-700 rounded-xl 
                    hover:bg-gray-100 active:bg-gray-200
                    active:scale-[0.98]
                    transition-all duration-200 
                    font-medium text-sm
                    min-h-[44px]
                    touch-manipulation
                  `,children:[e.jsxs("span",{className:"flex items-center gap-2",children:[e.jsx(x,{size:16}),"Check Compliance"]}),e.jsx(a,{size:16})]})]})]}),e.jsxs("div",{className:"bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl md:rounded-2xl shadow-lg p-4 sm:p-6 text-white",children:[e.jsx(x,{size:28,className:"mb-3"}),e.jsx("h3",{className:"font-semibold text-base sm:text-lg mb-2",children:"Security Status"}),e.jsx("p",{className:"text-blue-100 text-sm mb-4",children:"All systems secure. No alerts."}),e.jsxs("div",{className:"flex items-center gap-2 text-sm pt-3 border-t border-white/20",children:[e.jsx(d,{size:16}),e.jsx("span",{children:"Last audit: 3 days ago"})]})]})]})]})]}),i&&e.jsx(S,{resource:i,onClose:()=>l(null)})]})}export{A as CTOHome};
//# sourceMappingURL=CTOHome-DTJXNG2q.js.map
