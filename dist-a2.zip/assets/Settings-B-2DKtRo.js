import{c as W,u as _,r as n,j as e,ag as B,O as T,U as E,M as H,S as V,L as Y,e as A,av as O,E as b,f,aa as $}from"./react-vendor-Bwx__XUe.js";import{g as G,s as z}from"./index-CNvYNPLA.js";import"./vendor-B6n4M5ha.js";import"./csv-BWKFWSAi.js";import"./query-C3fsR7i0.js";import"./office-05PtlIje.js";import"./supabase-vendor-eBI8805-.js";import"./ui-libs-RUH28Cwu.js";function ne(){const x=W(),L=_(),{profile:d,user:w,isDemoMode:l,signOut:M}=G(),[h,y]=n.useState(""),[t,j]=n.useState(""),[r,N]=n.useState(""),[u,U]=n.useState(!1),[g,I]=n.useState(!1),[p,Z]=n.useState(!1),[o,v]=n.useState(!1),[P,i]=n.useState(null),[k,C]=n.useState(null),q=L.pathname.startsWith("/ceod")?"/ceod/home":"/ctod/home",D=s=>{const a=[];return s.length<8&&a.push("Password must be at least 8 characters"),/[A-Z]/.test(s)||a.push("Password must contain at least one uppercase letter"),/[a-z]/.test(s)||a.push("Password must contain at least one lowercase letter"),/[0-9]/.test(s)||a.push("Password must contain at least one number"),a},F=s=>{let a=0;return s.length>=8&&a++,s.length>=12&&a++,/[A-Z]/.test(s)&&a++,/[a-z]/.test(s)&&a++,/[0-9]/.test(s)&&a++,/[^A-Za-z0-9]/.test(s)&&a++,a<=2?{strength:1,label:"Weak",color:"bg-red-500"}:a<=4?{strength:2,label:"Medium",color:"bg-yellow-500"}:{strength:3,label:"Strong",color:"bg-green-500"}},R=async s=>{if(s.preventDefault(),i(null),C(null),l){i("Password cannot be changed in demo mode");return}if(t!==r){i("New passwords do not match");return}const a=D(t);if(a.length>0){i(a[0]);return}v(!0);try{const{error:m}=await z.auth.signInWithPassword({email:w?.email||"",password:h});if(m)throw new Error("Current password is incorrect");const{error:S}=await z.auth.updateUser({password:t});if(S)throw S;C("Password updated successfully!"),y(""),j(""),N("")}catch(m){i(m instanceof Error?m.message:"Failed to update password")}finally{v(!1)}},c=F(t);return e.jsx("div",{className:"min-h-screen bg-gradient-to-br from-slate-50 via-gray-50 to-slate-100 p-4 sm:p-6 md:p-8",style:{paddingTop:"max(1rem, env(safe-area-inset-top))"},children:e.jsxs("div",{className:"max-w-2xl mx-auto",children:[e.jsxs("div",{className:"mb-6 sm:mb-8",children:[e.jsxs("button",{onClick:()=>x(q),className:`
              flex items-center gap-2 
              text-gray-600 hover:text-gray-900 
              mb-4 transition-colors
              py-2 -ml-2 px-2 rounded-lg
              hover:bg-gray-100 active:bg-gray-200
              touch-manipulation min-h-[44px]
            `,children:[e.jsx(B,{className:"w-5 h-5"}),e.jsx("span",{className:"text-sm font-medium",children:"Back to Dashboard"})]}),e.jsxs("div",{className:"flex items-center gap-3",children:[e.jsx("div",{className:"p-2.5 sm:p-3 bg-gradient-to-br from-sky-500 to-blue-600 rounded-xl shadow-lg",children:e.jsx(T,{className:"w-5 h-5 sm:w-6 sm:h-6 text-white"})}),e.jsxs("div",{children:[e.jsx("h1",{className:"text-xl sm:text-2xl font-bold text-gray-900",children:"Account Settings"}),e.jsx("p",{className:"text-sm text-gray-500",children:"Manage your account security"})]})]})]}),e.jsxs("div",{className:"bg-white rounded-2xl shadow-sm border border-gray-100 p-4 sm:p-6 mb-4 sm:mb-6",children:[e.jsxs("h2",{className:"text-base sm:text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2",children:[e.jsx(E,{className:"w-5 h-5 text-gray-400"}),"Profile Information"]}),e.jsxs("div",{className:"space-y-3",children:[e.jsxs("div",{className:"flex items-center gap-3 p-3 sm:p-4 bg-gray-50 rounded-xl",children:[e.jsx(H,{className:"w-5 h-5 text-gray-400 flex-shrink-0"}),e.jsxs("div",{className:"min-w-0",children:[e.jsx("p",{className:"text-xs text-gray-500 uppercase tracking-wide",children:"Email"}),e.jsx("p",{className:"text-gray-900 font-medium text-sm sm:text-base truncate",children:w?.email||d?.email||"Not set"})]})]}),e.jsxs("div",{className:"flex items-center gap-3 p-3 sm:p-4 bg-gray-50 rounded-xl",children:[e.jsx(E,{className:"w-5 h-5 text-gray-400 flex-shrink-0"}),e.jsxs("div",{className:"min-w-0",children:[e.jsx("p",{className:"text-xs text-gray-500 uppercase tracking-wide",children:"Name"}),e.jsx("p",{className:"text-gray-900 font-medium text-sm sm:text-base truncate",children:d?.full_name||d?.display_name||"Not set"})]})]}),e.jsxs("div",{className:"flex items-center gap-3 p-3 sm:p-4 bg-gray-50 rounded-xl",children:[e.jsx(V,{className:"w-5 h-5 text-gray-400 flex-shrink-0"}),e.jsxs("div",{className:"min-w-0",children:[e.jsx("p",{className:"text-xs text-gray-500 uppercase tracking-wide",children:"Role"}),e.jsx("p",{className:"text-gray-900 font-medium text-sm sm:text-base capitalize",children:d?.role||"Staff"})]})]})]})]}),e.jsxs("div",{className:"bg-white rounded-2xl shadow-sm border border-gray-100 p-4 sm:p-6",children:[e.jsxs("h2",{className:"text-base sm:text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2",children:[e.jsx(Y,{className:"w-5 h-5 text-gray-400"}),"Change Password"]}),l&&e.jsxs("div",{className:"mb-4 p-3 sm:p-4 bg-amber-50 border border-amber-200 rounded-xl flex items-start gap-3",children:[e.jsx(A,{className:"w-5 h-5 text-amber-500 flex-shrink-0 mt-0.5"}),e.jsxs("div",{children:[e.jsx("p",{className:"text-amber-800 font-medium text-sm",children:"Demo Mode Active"}),e.jsx("p",{className:"text-amber-700 text-xs sm:text-sm",children:"Password changes are disabled in demo mode."})]})]}),P&&e.jsxs("div",{className:"mb-4 p-3 sm:p-4 bg-red-50 border border-red-200 rounded-xl flex items-start gap-3",children:[e.jsx(A,{className:"w-5 h-5 text-red-500 flex-shrink-0 mt-0.5"}),e.jsx("p",{className:"text-red-700 text-sm",children:P})]}),k&&e.jsxs("div",{className:"mb-4 p-3 sm:p-4 bg-green-50 border border-green-200 rounded-xl flex items-start gap-3",children:[e.jsx(O,{className:"w-5 h-5 text-green-500 flex-shrink-0 mt-0.5"}),e.jsx("p",{className:"text-green-700 text-sm",children:k})]}),e.jsxs("form",{onSubmit:R,className:"space-y-5",children:[e.jsxs("div",{children:[e.jsx("label",{htmlFor:"currentPassword",className:"block text-sm font-medium text-gray-700 mb-2",children:"Current Password"}),e.jsxs("div",{className:"relative",children:[e.jsx("input",{id:"currentPassword",type:u?"text":"password",value:h,onChange:s=>y(s.target.value),disabled:l||o,className:`
                    w-full px-4 py-3.5 pr-14 
                    border border-gray-200 rounded-xl 
                    focus:ring-2 focus:ring-sky-500 focus:border-transparent 
                    transition-all 
                    disabled:bg-gray-100 disabled:cursor-not-allowed
                    text-base min-h-[52px]
                  `,placeholder:"Enter your current password",required:!0}),e.jsx("button",{type:"button",onClick:()=>U(!u),className:`
                    absolute right-3 top-1/2 -translate-y-1/2 
                    p-2 rounded-lg
                    text-gray-400 hover:text-gray-600 hover:bg-gray-100
                    transition-colors touch-manipulation
                    min-h-[40px] min-w-[40px]
                    flex items-center justify-center
                  `,children:u?e.jsx(b,{className:"w-5 h-5"}):e.jsx(f,{className:"w-5 h-5"})})]})]}),e.jsxs("div",{children:[e.jsx("label",{htmlFor:"newPassword",className:"block text-sm font-medium text-gray-700 mb-2",children:"New Password"}),e.jsxs("div",{className:"relative",children:[e.jsx("input",{id:"newPassword",type:g?"text":"password",value:t,onChange:s=>j(s.target.value),disabled:l||o,className:`
                    w-full px-4 py-3.5 pr-14 
                    border border-gray-200 rounded-xl 
                    focus:ring-2 focus:ring-sky-500 focus:border-transparent 
                    transition-all 
                    disabled:bg-gray-100 disabled:cursor-not-allowed
                    text-base min-h-[52px]
                  `,placeholder:"Enter your new password",required:!0}),e.jsx("button",{type:"button",onClick:()=>I(!g),className:`
                    absolute right-3 top-1/2 -translate-y-1/2 
                    p-2 rounded-lg
                    text-gray-400 hover:text-gray-600 hover:bg-gray-100
                    transition-colors touch-manipulation
                    min-h-[40px] min-w-[40px]
                    flex items-center justify-center
                  `,children:g?e.jsx(b,{className:"w-5 h-5"}):e.jsx(f,{className:"w-5 h-5"})})]}),t&&e.jsxs("div",{className:"mt-3",children:[e.jsxs("div",{className:"flex items-center gap-2 mb-2",children:[e.jsx("div",{className:"flex-1 h-2 bg-gray-200 rounded-full overflow-hidden",children:e.jsx("div",{className:`h-full transition-all ${c.color}`,style:{width:`${c.strength/3*100}%`}})}),e.jsx("span",{className:`text-xs font-medium ${c.strength===1?"text-red-500":c.strength===2?"text-yellow-500":"text-green-500"}`,children:c.label})]}),e.jsxs("ul",{className:"text-xs text-gray-500 space-y-1.5 mt-2",children:[e.jsxs("li",{className:`flex items-center gap-1.5 ${t.length>=8?"text-green-600":""}`,children:[e.jsx("span",{className:"w-4",children:t.length>=8?"✓":"○"}),"At least 8 characters"]}),e.jsxs("li",{className:`flex items-center gap-1.5 ${/[A-Z]/.test(t)?"text-green-600":""}`,children:[e.jsx("span",{className:"w-4",children:/[A-Z]/.test(t)?"✓":"○"}),"One uppercase letter"]}),e.jsxs("li",{className:`flex items-center gap-1.5 ${/[a-z]/.test(t)?"text-green-600":""}`,children:[e.jsx("span",{className:"w-4",children:/[a-z]/.test(t)?"✓":"○"}),"One lowercase letter"]}),e.jsxs("li",{className:`flex items-center gap-1.5 ${/[0-9]/.test(t)?"text-green-600":""}`,children:[e.jsx("span",{className:"w-4",children:/[0-9]/.test(t)?"✓":"○"}),"One number"]})]})]})]}),e.jsxs("div",{children:[e.jsx("label",{htmlFor:"confirmPassword",className:"block text-sm font-medium text-gray-700 mb-2",children:"Confirm New Password"}),e.jsxs("div",{className:"relative",children:[e.jsx("input",{id:"confirmPassword",type:p?"text":"password",value:r,onChange:s=>N(s.target.value),disabled:l||o,className:`
                    w-full px-4 py-3.5 pr-14 
                    border rounded-xl 
                    focus:ring-2 focus:ring-sky-500 focus:border-transparent 
                    transition-all 
                    disabled:bg-gray-100 disabled:cursor-not-allowed
                    text-base min-h-[52px]
                    ${r&&t!==r?"border-red-300 bg-red-50":r&&t===r?"border-green-300 bg-green-50":"border-gray-200"}
                  `,placeholder:"Confirm your new password",required:!0}),e.jsx("button",{type:"button",onClick:()=>Z(!p),className:`
                    absolute right-3 top-1/2 -translate-y-1/2 
                    p-2 rounded-lg
                    text-gray-400 hover:text-gray-600 hover:bg-gray-100
                    transition-colors touch-manipulation
                    min-h-[40px] min-w-[40px]
                    flex items-center justify-center
                  `,children:p?e.jsx(b,{className:"w-5 h-5"}):e.jsx(f,{className:"w-5 h-5"})})]}),r&&t!==r&&e.jsx("p",{className:"mt-2 text-sm text-red-500",children:"Passwords do not match"}),r&&t===r&&e.jsxs("p",{className:"mt-2 text-sm text-green-500 flex items-center gap-1",children:[e.jsx(O,{className:"w-4 h-4"})," Passwords match"]})]}),e.jsx("button",{type:"submit",disabled:l||o||!h||!t||!r||t!==r,className:`
                w-full py-4 px-4 
                bg-gradient-to-r from-sky-500 to-blue-600 
                text-white font-semibold rounded-xl 
                shadow-lg hover:shadow-xl 
                hover:from-sky-600 hover:to-blue-700 
                focus:ring-2 focus:ring-sky-500 focus:ring-offset-2 
                transition-all duration-200
                disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:shadow-lg
                active:scale-[0.98]
                min-h-[52px]
                touch-manipulation
                text-sm sm:text-base
              `,children:o?e.jsxs("span",{className:"flex items-center justify-center gap-2",children:[e.jsxs("svg",{className:"animate-spin h-5 w-5",viewBox:"0 0 24 24",children:[e.jsx("circle",{className:"opacity-25",cx:"12",cy:"12",r:"10",stroke:"currentColor",strokeWidth:"4",fill:"none"}),e.jsx("path",{className:"opacity-75",fill:"currentColor",d:"M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"})]}),"Updating Password..."]}):"Update Password"})]})]}),e.jsxs("div",{className:"mt-4 sm:mt-6 p-4 bg-blue-50 border border-blue-100 rounded-xl",children:[e.jsx("h3",{className:"text-sm font-semibold text-blue-900 mb-2",children:"Security Tips"}),e.jsxs("ul",{className:"text-xs sm:text-sm text-blue-700 space-y-1.5",children:[e.jsx("li",{children:"• Use a unique password that you don't use for other accounts"}),e.jsx("li",{children:"• Never share your password with anyone"}),e.jsx("li",{children:"• Consider using a password manager"}),e.jsx("li",{children:"• Change your password periodically for better security"})]})]}),e.jsxs("div",{className:"mt-4 sm:mt-6 bg-white rounded-2xl shadow-sm border border-gray-100 p-4 sm:p-6",children:[e.jsxs("h2",{className:"text-base sm:text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2",children:[e.jsx($,{className:"w-5 h-5 text-gray-400"}),"Sign Out"]}),e.jsx("p",{className:"text-sm text-gray-500 mb-4",children:"Sign out of your account on this device. You will need to sign in again to access the dashboard."}),e.jsxs("button",{onClick:async()=>{try{sessionStorage.removeItem("mpb_access_verified"),await M(),x("/login")}catch(s){console.error("Error signing out:",s),x("/login")}},className:`
              w-full py-4 px-4 
              bg-gradient-to-r from-red-500 to-red-600 
              text-white font-semibold rounded-xl 
              shadow-lg hover:shadow-xl 
              hover:from-red-600 hover:to-red-700 
              focus:ring-2 focus:ring-red-500 focus:ring-offset-2 
              transition-all duration-200
              active:scale-[0.98]
              min-h-[52px]
              touch-manipulation
              text-sm sm:text-base
              flex items-center justify-center gap-2
            `,children:[e.jsx($,{className:"w-5 h-5"}),"Sign Out"]})]})]})})}export{ne as default};
//# sourceMappingURL=Settings-B-2DKtRo.js.map
