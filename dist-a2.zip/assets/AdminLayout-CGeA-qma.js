import{c as D,u as I,r as l,j as e,a6 as J,a7 as O,a8 as Y,a9 as Z,a3 as L,ar as B,k as E,y as ee,l as te,an as _,m as T,x as z,D as R,e as U,S as se,aD as ae,aw as ne,bx as ie,aX as le,O as re,a2 as oe,ap as ce,aa as de,i as me}from"./react-vendor-Bwx__XUe.js";import{g as ue,D as xe}from"./index-CNvYNPLA.js";import{u as F,A as he}from"./AdminStatsContext-hvoFWPzy.js";import"./vendor-B6n4M5ha.js";import"./csv-BWKFWSAi.js";import"./query-C3fsR7i0.js";import"./office-05PtlIje.js";import"./supabase-vendor-eBI8805-.js";import"./ui-libs-RUH28Cwu.js";const pe=[{title:"Dashboard",items:[{id:"overview",label:"Overview",icon:E,path:"/admin"}]},{title:"Analytics",items:[{id:"live",label:"Live View",icon:ee,path:"/admin/live"},{id:"analytics",label:"Analytics Overview",icon:te,path:"/admin/analytics"},{id:"traffic",label:"Traffic Sources",icon:L,path:"/admin/traffic"},{id:"marketing",label:"Marketing Analytics",icon:_,path:"/admin/marketing"}]},{title:"Operations",items:[{id:"members",label:"Member Management",icon:T,path:"/admin/members",badge:"total_members"},{id:"claims",label:"Claims Processing",icon:z,path:"/admin/claims",badge:"pending_claims",urgent:!0},{id:"transactions",label:"Transactions",icon:R,path:"/admin/transactions"},{id:"support",label:"Support Tickets",icon:U,path:"/admin/support",badge:"pending_support_tickets",urgent:!0},{id:"documents",label:"Document Review",icon:se,path:"/admin/documents"},{id:"providers",label:"Provider Directory",icon:ae,path:"/admin/providers"}]},{title:"Content",items:[{id:"blog",label:"Blog Management",icon:ne,path:"/admin/blog"},{id:"faq",label:"FAQ Management",icon:ie,path:"/admin/faq"},{id:"notifications",label:"Notifications",icon:le,path:"/admin/notifications"}]},{title:"SEO",items:[{id:"seo-analytics",label:"SEO Analytics",icon:_,path:"/admin/seo-analytics"},{id:"seo-settings",label:"SEO Settings",icon:B,path:"/admin/seo-settings"}]},{title:"Settings",items:[{id:"settings",label:"System Settings",icon:re,path:"/admin/settings"},{id:"health",label:"Health Monitor",icon:oe,path:"/admin/health"}]}];function be({isExpanded:t,onToggle:n}){const o=D(),c=I(),{signOut:d,profile:r,isDemoMode:m}=ue(),{stats:p}=F(),[i,u]=l.useState(!1),[b,N]=l.useState([]),P=l.useRef(null),k=l.useRef(0),[y,C]=l.useState(0),[f,$]=l.useState(!1);l.useEffect(()=>{const a=()=>{u(window.innerWidth<768)};return a(),window.addEventListener("resize",a),()=>window.removeEventListener("resize",a)},[]);const X=l.useCallback(a=>{!i||!t||(k.current=a.touches[0].clientX,$(!0))},[i,t]),W=l.useCallback(a=>{if(!f||!i)return;const s=a.touches[0].clientX-k.current;s<0&&C(s)},[f,i]),V=l.useCallback(()=>{f&&($(!1),y<-100&&n(),C(0))},[f,y,n]),q=async()=>{try{sessionStorage.removeItem("mpb_access_verified"),await d(),m||(window.location.href="/login")}catch(a){console.error("Error logging out:",a),o("/login")}},A=a=>{o(a),i&&n()},G=(a,s)=>{if(!a)return!1;const x=c.pathname;return x===a?!0:s?s.some(g=>x===g.path||x.startsWith(g.path+"/")):x.startsWith(a+"/")},H=a=>{N(s=>s.includes(a)?s.filter(x=>x!==a):[...s,a])},Q=f&&i?`translateX(${Math.max(y,-320)}px)`:void 0;return e.jsxs(e.Fragment,{children:[i&&t&&e.jsx("div",{className:"fixed inset-0 bg-black/60 backdrop-blur-sm z-30 md:hidden transition-opacity duration-300",onClick:n}),e.jsxs("div",{ref:P,onTouchStart:X,onTouchMove:W,onTouchEnd:V,className:`
          bg-gradient-to-b from-slate-900 via-slate-900 to-slate-950
          text-white h-screen flex flex-col overflow-y-auto overflow-x-hidden
          fixed top-0 left-0 z-40 shadow-2xl
          transition-transform duration-300 ease-out
          border-r border-slate-800
          ${t?"w-64":"w-[72px]"}
          ${i&&!t?"-translate-x-full":"translate-x-0"}
          will-change-transform
        `,style:{transform:Q,paddingBottom:"env(safe-area-inset-bottom)"},children:[e.jsx("button",{className:`
            absolute top-4 -right-14 p-3 rounded-full 
            bg-slate-800 text-white md:hidden z-50 
            shadow-lg active:scale-95 transition-transform
            touch-manipulation
          `,onClick:n,"aria-label":t?"Close menu":"Open menu",children:t?e.jsx(J,{className:"w-6 h-6"}):e.jsx(O,{className:"w-6 h-6"})}),e.jsx("button",{className:`
            hidden md:flex items-center justify-center
            absolute top-6 right-0 transform translate-x-1/2 
            w-8 h-8 rounded-full 
            bg-slate-700 hover:bg-slate-600 
            text-white z-50 cursor-pointer
            transition-all duration-200 hover:scale-110
          `,onClick:n,children:t?e.jsx(Y,{className:"w-4 h-4"}):e.jsx(Z,{className:"w-4 h-4"})}),e.jsxs("div",{className:`${t?"p-4":"p-3"} flex-1 flex flex-col`,style:{paddingTop:"max(1rem, env(safe-area-inset-top))"},children:[e.jsx("div",{className:"mb-6",children:e.jsxs("div",{className:`flex items-center ${t?"space-x-3":"justify-center"}`,children:[e.jsx("div",{className:`
                ${t?"w-10 h-10":"w-9 h-9"} 
                rounded-xl flex items-center justify-center shadow-lg 
                bg-gradient-to-br from-emerald-500 to-emerald-600
              `,children:e.jsx(L,{className:"w-5 h-5 text-white"})}),t&&e.jsxs("div",{children:[e.jsx("h1",{className:"text-lg font-bold text-white",children:"Web Control"}),e.jsx("p",{className:"text-slate-400 text-xs",children:"Admin Center"})]})]})}),t&&e.jsx("div",{className:"mb-4",children:e.jsx(xe,{variant:"dropdown"})}),t&&e.jsxs("div",{className:"mb-4 px-3 py-2 bg-slate-800/50 rounded-lg text-xs text-slate-400 flex items-center gap-2",children:[e.jsx(B,{className:"w-3.5 h-3.5"}),e.jsxs("span",{children:["Press ",e.jsx("kbd",{className:"px-1.5 py-0.5 bg-slate-700 rounded text-slate-300 font-mono",children:"⌘K"})," to search"]})]}),e.jsx("nav",{className:"flex-1 space-y-4 overflow-y-auto",children:pe.map(a=>e.jsxs("div",{children:[t&&e.jsx("h3",{className:"text-xs font-semibold uppercase tracking-wider text-slate-500 mb-2 px-3",children:a.title}),e.jsx("ul",{className:"space-y-1",children:a.items.map(s=>{const x=s.icon,g=G(s.path,s.submenu),j=s.submenu&&s.submenu.length>0,M=b.includes(s.id),v=s.badge?p[s.badge]:null;return e.jsxs("li",{children:[e.jsxs("button",{onClick:()=>{j&&t?H(s.id):s.path&&A(s.path)},title:s.label,className:`
                            flex items-center w-full px-3 py-2.5 rounded-lg
                            transition-all duration-200 group
                            ${g&&!j?"bg-primary-500/10 border-l-2 border-primary-400 text-white font-medium":"text-slate-300 hover:bg-slate-800/50 hover:text-white"}
                            ${t?"space-x-3":"justify-center"}
                          `,children:[e.jsxs("div",{className:"relative",children:[e.jsx(x,{className:`w-5 h-5 flex-shrink-0 ${g?"text-primary-400":""}`}),s.urgent&&v&&v>0&&!t&&e.jsx("span",{className:"absolute -top-1 -right-1 w-2 h-2 bg-red-500 rounded-full animate-ping"})]}),t&&e.jsxs(e.Fragment,{children:[e.jsx("span",{className:"flex-1 text-sm text-left",children:s.label}),v!==null&&v>0&&e.jsx("span",{className:`
                                  px-2 py-0.5 text-xs font-medium rounded-full
                                  ${s.urgent?"bg-red-500/20 text-red-400":"bg-slate-700 text-slate-300"}
                                `,children:v}),j&&e.jsx(ce,{className:`
                                  w-4 h-4 transition-transform duration-200
                                  ${M?"rotate-90":""}
                                `})]})]}),j&&M&&t&&e.jsx("ul",{className:"mt-1 ml-4 pl-3 border-l border-slate-700 space-y-1",children:s.submenu.map(h=>{const K=c.pathname===h.path,S=h.badge?p[h.badge]:null;return e.jsx("li",{children:e.jsxs("button",{onClick:()=>A(h.path),className:`
                                      flex items-center w-full px-3 py-2 rounded-lg text-sm
                                      transition-all duration-200
                                      ${K?"bg-primary-500/10 text-primary-400 font-medium":"text-slate-400 hover:bg-slate-800/50 hover:text-white"}
                                    `,children:[e.jsx("span",{className:"flex-1 text-left",children:h.label}),S!==null&&S>0&&e.jsx("span",{className:`
                                        px-2 py-0.5 text-xs font-medium rounded-full
                                        ${h.urgent?"bg-red-500/20 text-red-400":"bg-slate-700 text-slate-300"}
                                      `,children:S})]})},h.id)})})]},s.id)})})]},a.title))}),e.jsxs("div",{className:"mt-auto pt-4 border-t border-slate-800",children:[e.jsxs("div",{className:`
              flex items-center ${t?"space-x-3 p-3":"justify-center p-2"} 
              rounded-lg transition-colors cursor-pointer mb-2
              hover:bg-slate-800
            `,children:[e.jsx("div",{className:"w-9 h-9 rounded-full flex items-center justify-center bg-gradient-to-br from-emerald-500 to-emerald-600 flex-shrink-0",children:e.jsx("span",{className:"text-sm font-bold text-white",children:r?.display_name?r.display_name.split(" ").map(a=>a[0]).join("").slice(0,2).toUpperCase():"AD"})}),t&&e.jsxs("div",{className:"flex-1 min-w-0",children:[e.jsx("p",{className:"text-sm font-medium text-white truncate",children:r?.display_name||r?.full_name||"Admin User"}),e.jsx("p",{className:"text-xs text-slate-400 truncate",children:"Super Admin"})]})]}),e.jsxs("button",{onClick:q,className:`
                flex items-center w-full px-3 py-2.5 rounded-lg
                transition-all duration-200 text-slate-400
                hover:bg-red-600 hover:text-white
                ${t?"space-x-3":"justify-center"}
              `,children:[e.jsx(de,{className:"w-5 h-5 flex-shrink-0"}),t&&e.jsx("span",{className:"text-sm",children:"Sign Out"})]})]})]})]})]})}const fe={blue:{bg:"bg-blue-50",iconBg:"bg-blue-100",icon:"text-blue-600",text:"text-blue-700",ring:"ring-blue-500/30"},purple:{bg:"bg-purple-50",iconBg:"bg-purple-100",icon:"text-purple-600",text:"text-purple-700",ring:"ring-purple-500/30"},emerald:{bg:"bg-emerald-50",iconBg:"bg-emerald-100",icon:"text-emerald-600",text:"text-emerald-700",ring:"ring-emerald-500/30"},red:{bg:"bg-red-50",iconBg:"bg-red-100",icon:"text-red-600",text:"text-red-700",ring:"ring-red-500/30"},amber:{bg:"bg-amber-50",iconBg:"bg-amber-100",icon:"text-amber-600",text:"text-amber-700",ring:"ring-amber-500/30"}};function w({label:t,value:n,icon:o,color:c,urgent:d,urgentValue:r,link:m,formatAsCurrency:p}){const i=D(),u=fe[c],b=p?new Intl.NumberFormat("en-US",{style:"currency",currency:"USD",maximumFractionDigits:0}).format(n):typeof n=="number"?n.toLocaleString():n,N=()=>{m&&i(m)};return e.jsxs("button",{onClick:N,disabled:!m,className:`
        relative flex items-center gap-3 p-4 rounded-xl
        ${u.bg} 
        transition-all duration-200 
        ${m?"cursor-pointer hover:shadow-md hover:scale-[1.02] active:scale-[0.98]":"cursor-default"}
        ${d&&r&&r>0?`ring-2 ${u.ring}`:""}
        w-full text-left
      `,children:[d&&r&&r>0&&e.jsx("span",{className:"absolute top-2 right-2",children:e.jsxs("span",{className:"relative flex h-2.5 w-2.5",children:[e.jsx("span",{className:"animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"}),e.jsx("span",{className:"relative inline-flex rounded-full h-2.5 w-2.5 bg-red-500"})]})}),e.jsx("div",{className:`p-2.5 rounded-lg ${u.iconBg}`,children:e.jsx(o,{className:`w-5 h-5 ${u.icon}`})}),e.jsxs("div",{className:"flex-1 min-w-0",children:[e.jsx("p",{className:"text-xs font-medium text-slate-500 truncate",children:t}),e.jsx("p",{className:`text-lg font-bold ${u.text} truncate`,children:b})]})]})}function ge(){const{stats:t,loading:n,refreshStats:o,lastUpdated:c}=F();return e.jsx("div",{className:"bg-white border-b border-slate-200 sticky top-0 z-10",children:e.jsxs("div",{className:"max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3",children:[e.jsxs("div",{className:"flex items-center justify-between mb-3",children:[e.jsx("h2",{className:"text-sm font-semibold text-slate-700",children:"Quick Stats"}),e.jsxs("div",{className:"flex items-center gap-2",children:[c&&e.jsxs("span",{className:"text-xs text-slate-400",children:["Updated ",c.toLocaleTimeString()]}),e.jsx("button",{onClick:o,disabled:n,className:`
                p-1.5 rounded-lg text-slate-400 
                hover:bg-slate-100 hover:text-slate-600
                transition-all duration-200
                ${n?"animate-spin":""}
              `,title:"Refresh stats",children:e.jsx(me,{className:"w-4 h-4"})})]})]}),e.jsxs("div",{className:"grid grid-cols-2 md:grid-cols-4 gap-3",children:[e.jsx(w,{label:"Members",value:t.total_members,icon:T,color:"blue",link:"/admin/members"}),e.jsx(w,{label:"Pending Claims",value:t.pending_claims,icon:z,color:t.pending_claims>0?"amber":"purple",urgent:!0,urgentValue:t.pending_claims,link:"/admin/claims"}),e.jsx(w,{label:"Revenue MTD",value:t.total_revenue_this_month,icon:R,color:"emerald",formatAsCurrency:!0,link:"/admin/transactions"}),e.jsx(w,{label:"Open Tickets",value:t.pending_support_tickets,icon:U,color:t.pending_support_tickets>0?"red":"blue",urgent:!0,urgentValue:t.pending_support_tickets,link:"/admin/support"})]})]})})}function ve({children:t,showStatsBar:n=!0}){const[o,c]=l.useState(!0),[d,r]=l.useState(!1);l.useEffect(()=>{function i(){const b=window.innerWidth<768;r(b),b&&c(!1)}return i(),window.addEventListener("resize",i),()=>window.removeEventListener("resize",i)},[]);const m=l.useCallback(()=>{c(i=>!i)},[]),p=()=>d?"pl-0":o?"md:pl-64":"md:pl-[72px]";return e.jsxs("div",{className:"flex min-h-screen bg-slate-50 overflow-hidden",children:[e.jsx(be,{isExpanded:o,onToggle:m}),d&&!o&&e.jsx("button",{className:`
            fixed z-50
            p-3 rounded-xl
            bg-emerald-600 text-white 
            shadow-lg shadow-emerald-500/30
            md:hidden
            touch-manipulation
            active:scale-95 active:bg-emerald-700
            transition-all duration-200
            min-h-[44px] min-w-[44px]
            flex items-center justify-center
          `,style:{top:"max(1rem, env(safe-area-inset-top))",left:"max(1rem, env(safe-area-inset-left))"},onClick:m,"aria-label":"Open navigation menu",children:e.jsx(O,{className:"w-5 h-5"})}),e.jsxs("main",{className:`
          flex-1 min-h-screen 
          overflow-y-auto overflow-x-hidden 
          transition-all duration-300 ease-out
          ${p()}
        `,children:[n&&e.jsx(ge,{}),e.jsx("div",{className:"w-full",style:{paddingTop:d&&!n?"max(4.5rem, calc(env(safe-area-inset-top) + 3.5rem))":void 0,paddingBottom:d?"max(1rem, env(safe-area-inset-bottom))":void 0},children:e.jsx("div",{className:"max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6",children:t})})]})]})}function Me({children:t,showStatsBar:n=!0}){return e.jsx(he,{children:e.jsx(ve,{showStatsBar:n,children:t})})}export{Me as AdminLayout,Me as default};
//# sourceMappingURL=AdminLayout-CGeA-qma.js.map
