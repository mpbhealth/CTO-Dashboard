import{u as O,f as E,m as L,$ as y,j as e,c as M,r as d,N as I,aH as j,x as v,l as B,aG as S,S as N,ao as T,aI as u,aa as w,a6 as C,a7 as k,ap as $}from"./react-vendor-Bwx__XUe.js";import{g as F,u as H}from"./index-CNvYNPLA.js";function z({context:m,label:n,className:x=""}){const h=O(),a=m||(()=>{const i=h.pathname;return i.includes("/departments/")?"department":i.includes("/team")||i.includes("/members")?"team":i.includes("/home")||i==="/ceod/home"||i==="/ctod/home"?"personal":"company"})(),g={company:{icon:y,color:"bg-blue-100 text-blue-800",defaultLabel:"Company View"},department:{icon:y,color:"bg-indigo-100 text-indigo-800",defaultLabel:"Department View"},team:{icon:L,color:"bg-sky-100 text-sky-800",defaultLabel:"Team View"},personal:{icon:E,color:"bg-emerald-100 text-emerald-800",defaultLabel:"Personal View"}},{icon:s,color:r,defaultLabel:c}=g[a];return e.jsxs("span",{className:`inline-flex items-center space-x-1 px-3 py-1 text-xs font-medium rounded-full ${r} ${x}`,children:[e.jsx(s,{className:"w-3 h-3"}),e.jsx("span",{children:n||c})]})}function A({children:m}){const n=O(),x=M(),{signOut:h,isDemoMode:b}=F(),{data:a,isLoading:g}=H(),[s,r]=d.useState(!1);if(d.useEffect(()=>(a?.role&&(document.documentElement.dataset.role=a.role),()=>{delete document.documentElement.dataset.role}),[a?.role]),d.useEffect(()=>{r(!1)},[n.pathname]),d.useEffect(()=>(s?document.body.style.overflow="hidden":document.body.style.overflow="",()=>{document.body.style.overflow=""}),[s]),g)return e.jsx("div",{className:"min-h-screen bg-gray-50 flex items-center justify-center",children:e.jsx("div",{className:"animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"})});if(a&&a.role!=="cto"&&a.role!=="admin"&&a.role!=="ceo"&&a.role!=="staff")return e.jsx(I,{to:"/ceod/home",replace:!0});const c=[{path:"/ctod/home",label:"Home",icon:j},{path:"/ctod/files",label:"Files",icon:v},{path:"/ctod/kpis",label:"KPIs",icon:B},{path:"/ctod/engineering",label:"Engineering",icon:S},{path:"/ctod/compliance",label:"Compliance",icon:N},{path:"/shared/overview",label:"Shared",icon:T}],i=[{path:"/ctod/home",label:"Home",icon:j},{path:"/ctod/files",label:"Files",icon:v},{path:"/ctod/compliance",label:"Compliance",icon:N}],f=async()=>{try{await h(),b||(window.location.href="/login")}catch(t){console.error("Error signing out:",t),x("/login")}},p=a?.role==="ceo";return e.jsxs("div",{className:"min-h-screen bg-gray-50",children:[e.jsx("nav",{className:"bg-white border-b border-gray-200 sticky top-0 z-30",style:{paddingTop:"env(safe-area-inset-top)"},children:e.jsx("div",{className:"max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8",children:e.jsxs("div",{className:"flex justify-between items-center h-14 md:h-16",children:[e.jsxs("div",{className:"flex items-center gap-4 lg:gap-6",children:[e.jsxs("div",{className:"flex items-center gap-2 md:gap-3",children:[e.jsx("img",{src:"/MPB-Health-No-background.png",alt:"MPB Health Logo",className:"h-8 md:h-10 w-auto object-contain"}),e.jsxs("div",{className:"hidden xs:block",children:[e.jsx("h1",{className:`text-sm md:text-lg font-bold leading-tight ${p?"bg-gradient-to-r from-indigo-600 to-blue-600 bg-clip-text text-transparent":"text-gray-900"}`,children:p?"CEO — CTO Overview":"CTO Dashboard"}),e.jsx("p",{className:"text-xs text-gray-500 truncate max-w-[150px] md:max-w-none",children:a?.display_name||a?.email})]})]}),e.jsx("div",{className:"hidden md:block h-6 w-px bg-gray-200"}),e.jsx("div",{className:"hidden md:flex items-center gap-2",children:c.map(t=>{const l=t.icon,o=n.pathname===t.path||n.pathname.startsWith(t.path+"/");return e.jsxs(u,{to:t.path,className:`
                        flex items-center gap-2 px-3 py-2 rounded-lg 
                        text-sm font-medium transition-all duration-200
                        min-h-touch
                        ${p?o?"bg-gradient-to-r from-indigo-50 to-blue-50 text-indigo-700":"text-gray-600 hover:bg-indigo-50 hover:text-indigo-700":o?"bg-indigo-50 text-indigo-700":"text-gray-600 hover:bg-gray-50 hover:text-gray-900"}
                      `,children:[e.jsx(l,{size:16}),e.jsx("span",{className:"hidden lg:inline",children:t.label})]},t.path)})})]}),e.jsxs("div",{className:"flex items-center gap-3 md:gap-4",children:[e.jsx("div",{className:"hidden sm:block",children:e.jsx(z,{})}),e.jsxs("button",{onClick:f,className:`
                  hidden md:flex items-center gap-2 
                  px-3 py-2 text-gray-600 hover:text-gray-900 
                  rounded-lg hover:bg-gray-50 transition-colors
                  min-h-touch
                `,children:[e.jsx(w,{size:16}),e.jsx("span",{className:"text-sm font-medium",children:"Sign Out"})]}),e.jsx("button",{onClick:()=>r(!s),className:`
                  md:hidden p-2.5 rounded-lg 
                  text-gray-600 hover:text-gray-900 hover:bg-gray-100
                  active:bg-gray-200 transition-colors
                  touch-manipulation min-h-touch min-w-touch
                  flex items-center justify-center
                `,"aria-label":s?"Close menu":"Open menu",children:s?e.jsx(C,{size:22}):e.jsx(k,{size:22})})]})]})})}),s&&e.jsxs(e.Fragment,{children:[e.jsx("div",{className:"fixed inset-0 bg-black/50 backdrop-blur-sm z-40 md:hidden animate-fade-in",onClick:()=>r(!1)}),e.jsxs("div",{className:`
              fixed top-0 right-0 bottom-0 w-[280px] max-w-[85vw]
              bg-white z-50 md:hidden
              shadow-2xl animate-slide-in-right
              flex flex-col
            `,style:{paddingTop:"env(safe-area-inset-top)"},children:[e.jsxs("div",{className:"flex items-center justify-between p-4 border-b border-gray-200",children:[e.jsx("span",{className:"font-semibold text-gray-900",children:"Menu"}),e.jsx("button",{onClick:()=>r(!1),className:`
                  p-2 rounded-lg text-gray-500 hover:text-gray-700 
                  hover:bg-gray-100 active:bg-gray-200
                  transition-colors touch-manipulation
                `,"aria-label":"Close menu",children:e.jsx(C,{size:20})})]}),e.jsx("nav",{className:"flex-1 overflow-y-auto p-3",children:e.jsx("div",{className:"space-y-1",children:c.map(t=>{const l=t.icon,o=n.pathname===t.path||n.pathname.startsWith(t.path+"/");return e.jsxs(u,{to:t.path,className:`
                        flex items-center justify-between
                        px-4 py-3.5 rounded-xl
                        text-base font-medium transition-all duration-200
                        touch-manipulation active:scale-[0.98]
                        min-h-touch
                        ${o?"bg-indigo-50 text-indigo-700":"text-gray-700 hover:bg-gray-50 active:bg-gray-100"}
                      `,children:[e.jsxs("div",{className:"flex items-center gap-3",children:[e.jsx(l,{size:20,className:o?"text-indigo-600":"text-gray-500"}),e.jsx("span",{children:t.label})]}),e.jsx($,{size:16,className:"text-gray-400"})]},t.path)})})}),e.jsxs("div",{className:"p-4 border-t border-gray-200",style:{paddingBottom:"max(1rem, env(safe-area-inset-bottom))"},children:[e.jsx("div",{className:"mb-3",children:e.jsx(z,{})}),e.jsxs("button",{onClick:f,className:`
                  w-full flex items-center justify-center gap-2
                  px-4 py-3 rounded-xl
                  text-red-600 bg-red-50 hover:bg-red-100
                  font-medium transition-colors
                  touch-manipulation active:scale-[0.98]
                  min-h-touch
                `,children:[e.jsx(w,{size:18}),e.jsx("span",{children:"Sign Out"})]})]})]})]}),e.jsx("main",{className:"w-full min-h-[calc(100vh-3.5rem)] md:min-h-[calc(100vh-4rem)]",style:{paddingBottom:"max(4.5rem, calc(4rem + env(safe-area-inset-bottom)))"},children:e.jsx("div",{className:"px-4 sm:px-6 md:px-8 py-4 sm:py-6 md:py-8",children:m})}),e.jsxs("div",{className:`
          fixed bottom-0 left-0 right-0 z-30 md:hidden
          bg-white border-t border-gray-200
          flex items-center justify-around
        `,style:{paddingBottom:"env(safe-area-inset-bottom)"},children:[i.map(t=>{const l=t.icon,o=n.pathname===t.path||n.pathname.startsWith(t.path+"/");return e.jsxs(u,{to:t.path,className:`
                flex flex-col items-center justify-center
                flex-1 py-2 min-h-[56px]
                text-xs font-medium
                transition-colors duration-200
                touch-manipulation active:bg-gray-100
                ${o?"text-indigo-600":"text-gray-500 hover:text-gray-700"}
              `,children:[e.jsx(l,{size:22,className:o?"text-indigo-600":"text-gray-400"}),e.jsx("span",{className:"mt-1",children:t.label})]},t.path)}),e.jsxs("button",{onClick:()=>r(!0),className:`
            flex flex-col items-center justify-center
            flex-1 py-2 min-h-[56px]
            text-xs font-medium text-gray-500
            transition-colors duration-200
            touch-manipulation active:bg-gray-100
          `,children:[e.jsx(k,{size:22,className:"text-gray-400"}),e.jsx("span",{className:"mt-1",children:"More"})]})]})]})}export{A as C};
//# sourceMappingURL=CTODashboardLayout-BwCwAoAm.js.map
