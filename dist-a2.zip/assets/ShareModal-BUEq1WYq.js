import{r as t,j as e,m as N,a6 as k,L as V,ao as S,a3 as D}from"./react-vendor-Bwx__XUe.js";import{u as U,c as W,d as F,e as $,f as B}from"./index-CNvYNPLA.js";function q({resource:n,onClose:a}){const{data:E}=U(),{data:g=[]}=W(n.id),m=F(),x=$(),b=B(),[l,C]=t.useState(n.visibility),[d,p]=t.useState(""),[f,v]=t.useState(!1),[i,A]=t.useState(!1),R=t.useRef(null),[c,y]=t.useState(!1),[_,j]=t.useState(0),u=t.useRef(0),o=t.useRef(0);t.useEffect(()=>{const s=()=>A(window.innerWidth<768);return s(),window.addEventListener("resize",s),()=>window.removeEventListener("resize",s)},[]),t.useEffect(()=>(document.body.style.overflow="hidden",()=>{document.body.style.overflow=""}),[]),t.useEffect(()=>{const s=r=>{r.key==="Escape"&&a()};return document.addEventListener("keydown",s),()=>document.removeEventListener("keydown",s)},[a]);const z=t.useCallback(s=>{i&&(u.current=s.touches[0].clientY,o.current=s.touches[0].clientY,y(!0))},[i]),O=t.useCallback(s=>{if(!c||!i)return;o.current=s.touches[0].clientY;const r=o.current-u.current;r>0&&j(r)},[c,i]),I=t.useCallback(()=>{c&&(y(!1),o.current-u.current>100&&a(),j(0))},[c,a]),P=async()=>{l!==n.visibility&&await m.mutateAsync({resourceId:n.id,visibility:l})},T=async s=>{s.preventDefault(),d.trim()&&(await x.mutateAsync({resourceId:n.id,granteeProfileId:d,canRead:!0,canWrite:f}),p(""),v(!1))},G=async s=>{await b.mutateAsync({resourceId:n.id,granteeProfileId:s})},L=[{value:"private",label:"Private",icon:V,description:"Only you can access"},{value:"shared_to_cto",label:"Share with CTO",icon:S,description:"CTO and admins can view"},{value:"shared_to_ceo",label:"Share with CEO",icon:S,description:"CEO and admins can view"},{value:"org_public",label:"Organization",icon:D,description:"All organization members can view"}],h=E?.user_id===n.created_by,Y=c&&i?`translateY(${_}px)`:"translateY(0)",w=()=>e.jsxs(e.Fragment,{children:[e.jsxs("div",{className:"p-4 sm:p-6 space-y-5 sm:space-y-6",children:[h&&e.jsxs(e.Fragment,{children:[e.jsxs("div",{children:[e.jsx("label",{className:"block text-sm font-medium text-gray-700 mb-3",children:"Visibility Level"}),e.jsx("div",{className:"space-y-2",children:L.map(s=>{const r=s.icon;return e.jsxs("label",{className:`
                        flex items-start gap-3 p-3 sm:p-4 
                        border rounded-xl cursor-pointer 
                        transition-all duration-200
                        touch-manipulation active:scale-[0.99]
                        ${l===s.value?"border-indigo-500 bg-indigo-50":"border-gray-200 hover:border-gray-300 active:bg-gray-50"}
                      `,children:[e.jsx("input",{type:"radio",name:"visibility",value:s.value,checked:l===s.value,onChange:M=>C(M.target.value),className:"mt-1 w-4 h-4 text-indigo-600"}),e.jsxs("div",{className:"flex-1 min-w-0",children:[e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx(r,{size:16,className:"text-gray-600 flex-shrink-0"}),e.jsx("span",{className:"font-medium text-gray-900 text-sm sm:text-base",children:s.label})]}),e.jsx("p",{className:"text-xs sm:text-sm text-gray-500 mt-1",children:s.description})]})]},s.value)})}),l!==n.visibility&&e.jsx("button",{onClick:P,disabled:m.isPending,className:`
                    mt-4 w-full sm:w-auto px-4 py-3 sm:py-2.5
                    bg-indigo-600 text-white rounded-xl 
                    hover:bg-indigo-700 active:bg-indigo-800
                    active:scale-[0.98]
                    transition-all duration-200 
                    disabled:opacity-50 disabled:cursor-not-allowed
                    font-medium text-sm
                    min-h-[44px]
                    touch-manipulation
                  `,children:m.isPending?"Updating...":"Update Visibility"})]}),e.jsxs("div",{className:"border-t pt-5 sm:pt-6",children:[e.jsx("label",{className:"block text-sm font-medium text-gray-700 mb-3",children:"Grant Specific Access"}),e.jsxs("form",{onSubmit:T,className:"space-y-3",children:[e.jsxs("div",{className:"flex flex-col sm:flex-row gap-2",children:[e.jsx("input",{type:"text",value:d,onChange:s=>p(s.target.value),placeholder:"Enter user ID or email",className:`
                      flex-1 px-4 py-3 
                      border border-gray-300 rounded-xl 
                      focus:ring-2 focus:ring-indigo-500 focus:border-transparent
                      text-base
                      min-h-[48px]
                    `}),e.jsx("button",{type:"submit",disabled:!d.trim()||x.isPending,className:`
                      px-6 py-3 
                      bg-green-600 text-white rounded-xl 
                      hover:bg-green-700 active:bg-green-800
                      active:scale-[0.98]
                      transition-all duration-200 
                      disabled:opacity-50 disabled:cursor-not-allowed
                      font-medium text-sm
                      min-h-[48px]
                      touch-manipulation
                      whitespace-nowrap
                    `,children:x.isPending?"Adding...":"Add"})]}),e.jsxs("label",{className:"flex items-center gap-3 text-sm py-1 touch-manipulation",children:[e.jsx("input",{type:"checkbox",checked:f,onChange:s=>v(s.target.checked),className:"w-5 h-5 rounded border-gray-300 text-indigo-600"}),e.jsx("span",{className:"text-gray-700",children:"Grant write permission"})]})]})]})]}),e.jsxs("div",{className:`${h?"border-t pt-5 sm:pt-6":""}`,children:[e.jsx("h3",{className:"text-sm font-medium text-gray-700 mb-3",children:"Current Access"}),e.jsxs("div",{className:"space-y-2",children:[e.jsx("div",{className:"flex items-center justify-between p-3 sm:p-4 bg-gray-50 rounded-xl",children:e.jsxs("div",{children:[e.jsx("p",{className:"font-medium text-gray-900 text-sm",children:"You (Owner)"}),e.jsx("p",{className:"text-xs text-gray-500",children:"Full access"})]})}),g.map(s=>e.jsxs("div",{className:"flex items-center justify-between p-3 sm:p-4 bg-gray-50 rounded-xl gap-3",children:[e.jsxs("div",{className:"min-w-0 flex-1",children:[e.jsx("p",{className:"font-medium text-gray-900 text-sm truncate",children:s.grantee_profile_id}),e.jsx("p",{className:"text-xs text-gray-500",children:s.can_write?"Read & Write":"Read only"})]}),h&&e.jsx("button",{onClick:()=>G(s.grantee_profile_id),disabled:b.isPending,className:`
                      text-red-600 hover:text-red-700 
                      text-sm font-medium 
                      px-3 py-2 rounded-lg
                      hover:bg-red-50 active:bg-red-100
                      transition-colors
                      touch-manipulation
                      min-h-[40px]
                      flex-shrink-0
                    `,children:"Remove"})]},s.id)),g.length===0&&e.jsx("p",{className:"text-sm text-gray-500 text-center py-4",children:"No additional access grants"})]})]})]}),e.jsx("div",{className:"sticky bottom-0 bg-gray-50 px-4 sm:px-6 py-4 border-t",style:{paddingBottom:i?"max(1rem, env(safe-area-inset-bottom))":void 0},children:e.jsx("button",{onClick:a,className:`
            w-full px-4 py-3 
            bg-gray-200 text-gray-700 rounded-xl 
            hover:bg-gray-300 active:bg-gray-400
            active:scale-[0.98]
            transition-all duration-200 
            font-medium text-sm
            min-h-[48px]
            touch-manipulation
          `,children:"Close"})})]});return e.jsxs("div",{className:"fixed inset-0 z-50",children:[e.jsx("div",{className:"absolute inset-0 bg-black/60 backdrop-blur-sm animate-fade-in",onClick:a,"aria-hidden":"true"}),e.jsx("div",{className:"hidden md:flex items-center justify-center min-h-screen p-4",children:e.jsxs("div",{className:"relative bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-hidden animate-scale-in",children:[e.jsxs("div",{className:"sticky top-0 bg-white border-b px-6 py-4 flex items-center justify-between z-10",children:[e.jsxs("div",{className:"flex items-center gap-3 min-w-0",children:[e.jsx("div",{className:"p-2 bg-indigo-100 rounded-lg flex-shrink-0",children:e.jsx(N,{className:"text-indigo-600",size:20})}),e.jsxs("div",{className:"min-w-0",children:[e.jsx("h2",{className:"text-lg font-semibold text-gray-900",children:"Share Settings"}),e.jsx("p",{className:"text-sm text-gray-500 truncate",children:n.title})]})]}),e.jsx("button",{onClick:a,className:`
                p-2 rounded-lg text-gray-400 
                hover:text-gray-600 hover:bg-gray-100
                transition-colors
                min-h-[40px] min-w-[40px]
                flex items-center justify-center
              `,"aria-label":"Close",children:e.jsx(k,{size:20})})]}),e.jsx("div",{className:"overflow-y-auto max-h-[calc(90vh-80px)]",children:e.jsx(w,{})})]})}),e.jsxs("div",{ref:R,className:`
          md:hidden fixed inset-x-0 bottom-0
          bg-white rounded-t-3xl shadow-bottom-sheet
          max-h-[85vh] overflow-hidden
          transition-transform duration-300 ease-out
          will-change-transform
        `,style:{transform:Y},children:[e.jsx("div",{className:"pt-3 pb-2 cursor-grab active:cursor-grabbing touch-manipulation",onTouchStart:z,onTouchMove:O,onTouchEnd:I,children:e.jsx("div",{className:"w-12 h-1.5 bg-gray-300 rounded-full mx-auto"})}),e.jsxs("div",{className:"px-4 py-3 border-b border-gray-200 flex items-center justify-between",children:[e.jsxs("div",{className:"flex items-center gap-3 min-w-0 flex-1",children:[e.jsx("div",{className:"p-2 bg-indigo-100 rounded-lg flex-shrink-0",children:e.jsx(N,{className:"text-indigo-600",size:18})}),e.jsxs("div",{className:"min-w-0",children:[e.jsx("h2",{className:"text-base font-semibold text-gray-900",children:"Share Settings"}),e.jsx("p",{className:"text-xs text-gray-500 truncate",children:n.title})]})]}),e.jsx("button",{onClick:a,className:`
              p-2.5 rounded-xl text-gray-400 
              hover:text-gray-600 hover:bg-gray-100
              active:bg-gray-200
              transition-colors touch-manipulation
              min-h-[44px] min-w-[44px]
              flex items-center justify-center
              flex-shrink-0
            `,"aria-label":"Close",children:e.jsx(k,{size:20})})]}),e.jsx("div",{className:"overflow-y-auto overscroll-contain",style:{maxHeight:"calc(85vh - 120px)"},children:e.jsx(w,{})})]})]})}export{q as S};
//# sourceMappingURL=ShareModal-BUEq1WYq.js.map
